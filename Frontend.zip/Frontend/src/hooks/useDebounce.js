import { useState, useEffect } from 'react'

const useDebounce = (value, delay = 300) => {

    const [debouncedValue, setDebouncedValue]  = useState(value);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);

        // cleanup 
        return () => clearTimeout(timer);
    }, [value, delay])

  return debouncedValue;
}

export default useDebounce;